/assign @gbiggs
<!--
FOR SUPPORT REQUESTS, please ask at ROS Answers: https://answers.ros.org/questions/ask/?tags=autoware, make sure to use the "autoware" tag.
For general discussion, please use the Autoware Discourse category: https://discourse.ros.org/c/autoware
Not sure if this is the right repository? Open an issue on https://gitlab.com/autowarefoundation/autoware.ai/autoware
For CONFIRMED bug reports, please use the bug report issue template.
For feature requests, please use the feature request issue template.
Be as detailed about your issue as possible.
-->

IF YOU ARE ASKING FOR SUPPORT please read the support guidelines: https://gitlab.com/autowarefoundation/autoware.ai/autoware/wikis/Support-guidelines
Ask support requests at ROS Answers: https://answers.ros.org/questions/ask/?tags=autoware 

